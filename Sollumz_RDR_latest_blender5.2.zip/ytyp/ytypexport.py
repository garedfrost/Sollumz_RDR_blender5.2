from typing import Iterable
import bpy
from mathutils import Euler, Vector, Quaternion, Matrix

from ..cwxml import ytyp as ytypxml, ymap as ymapxml
from ..sollumz_properties import ArchetypeType, AssetType, EntityLodLevel, EntityPriorityLevel, SollumzGame, MapEntityType, import_export_current_game as current_game, set_import_export_current_game
from ..tools import jenkhash
from ..tools.meshhelper import get_combined_bound_box, get_bound_center_from_bounds, get_sphere_radius
from .properties.ytyp import ArchetypeProperties, SpecialAttribute, TimecycleModifierProperties, RoomProperties, PortalProperties, MloEntityProperties, EntitySetProperties
from .properties.extensions import ExtensionProperties, ExtensionType
from ..ydr.light_flashiness import Flashiness
from ..cwxml.ytyp import restore_xml, unsigned


def preserve_attached_object_order(properties, xml):
    if current_game() != SollumzGame.RDR or not properties.get('_rdr_xml'):
        return
    from xml.etree import ElementTree as ET
    source = ET.fromstring(properties['_rdr_xml']).find('attachedObjects')
    if source is not None:
        original = ytypxml.AttachedObjectsBuffer.from_xml(source).value
        if {index for index in original if index not in (-1, 0xFFFFFFFF)} == set(xml.attached_objects):
            xml.attached_objects = original


def set_room_attached_objects(room_xml: ytypxml.Room, room_index: int, entities: Iterable[MloEntityProperties]):
    """Set attached objects of room from the mlo archetype entities collection provided."""
    for i, entity in enumerate(entities):
        if entity.room_index == room_index:
            room_xml.attached_objects.append(i)


def set_portal_attached_objects(portal_xml: ytypxml.Portal, portal_index: int, entities: Iterable[MloEntityProperties]):
    """Set attached objects of portal from the mlo archetype entities collection provided."""
    for i, entity in enumerate(entities):
        if entity.portal_index == portal_index:
            portal_xml.attached_objects.append(i)


def get_portal_count(room: RoomProperties, portals: Iterable[PortalProperties]) -> int:
    """Get number of portals in room."""

    count = 0
    for portal in portals:
        if portal.room_from_id == str(room.id) or portal.room_to_id == str(room.id):
            count += 1

    return count


def set_entity_xml_transforms_from_object(entity_obj: bpy.types.Object, entity_xml: ymapxml.Entity, archetype: ArchetypeProperties):
    """Set the transforms of an entity xml based on a Blender mesh object."""

    transform: Matrix = entity_obj.matrix_world
    if archetype.asset is not None:
        # Get transform relative to MLO collisions object
        parent_transform_inv = archetype.asset.matrix_world.inverted()
        transform = parent_transform_inv @ transform
    location, rotation, scale = transform.decompose()

    entity_xml.position = location
    entity_xml.rotation = rotation.inverted()
    entity_xml.scale_xy = scale.x
    entity_xml.scale_z = scale.z


def set_entity_xml_transforms(entity: MloEntityProperties, entity_xml: ymapxml.Entity):
    """Set the transforms of an entity xml based on the provided entity data-block."""

    entity_xml.position = Vector(entity.position)
    entity_xml.rotation = Quaternion(entity.rotation.inverted())
    entity_xml.scale_xy = entity.scale_xy
    entity_xml.scale_z = entity.scale_z


def set_portal_xml_corners(portal: PortalProperties, portal_xml: ytypxml.Portal):
    """Set all 4 corners of portal xml based on portal data-block."""

    for i in range(4):
        corner = getattr(portal, f"corner{i + 1}")
        corner_xml = ytypxml.Corner()
        corner_xml.value = corner
        portal_xml.corners.append(corner_xml)


def create_entity_set_xml(entityset: EntitySetProperties, archetype: ArchetypeProperties) -> ytypxml.EntitySet:
    """Create xml mlo entity sets from an entityset data-block"""
    entity_set = ytypxml.EntitySet()
    restore_xml(entityset, entity_set)
    entity_set.name = entityset.name

    for entity in archetype.entities:
        if entity.attached_entity_set_id != str(entityset.id):
            continue

        entity_set.entities.append(create_entity_xml(entity, archetype))

        location = entity.room_index
        if location == -1:
            # If not attached to a room, it should be attached to a portal. Set MSB to indicate this is a portal index
            location = entity.portal_index | (1 << 31)

        entity_set.locations.append(location)

    return entity_set


def create_entity_xml(entity: MloEntityProperties, archetype: ArchetypeProperties) -> ymapxml.Entity:
    """Create xml mlo entity from an entity data-block."""

    entity_xml = ytypxml.RDRYtypEntity() if current_game() == SollumzGame.RDR else ymapxml.Entity()
    restore_xml(entity, entity_xml)
    entity_obj = entity.linked_object
    if entity_obj:
        set_entity_xml_transforms_from_object(entity_obj, entity_xml, archetype)
    else:
        set_entity_xml_transforms(entity, entity_xml)

    entity_xml.archetype_name = entity.archetype_name
    entity_xml.flags = entity.flags.total
    entity_xml.parent_index = entity.parent_index
    entity_xml.guid = unsigned(entity.rdr_id) if current_game() == SollumzGame.RDR else entity.guid
    entity_xml.num_children = entity.num_children
    entity_xml.lod_dist = entity.lod_dist
    entity_xml.child_lod_dist = entity.child_lod_dist
    if current_game() == SollumzGame.GTA:
        entity_xml.ambient_occlusion_multiplier = entity.ambient_occlusion_multiplier
        entity_xml.artificial_ambient_occlusion = entity.artificial_ambient_occlusion
    entity_xml.tint_value = entity.tint_value
    if current_game() == SollumzGame.RDR:
        entity_xml.power_grid_id = unsigned(entity.power_grid_id, 32)
        entity_xml.blend_age_layer = entity.blend_age_layer
        entity_xml.blend_age_dirt = entity.blend_age_dirt

    lod_level = next(name for name, value in vars(
        EntityLodLevel).items() if value == (entity.lod_level))
    priority_level = next(name for name, value in vars(
        EntityPriorityLevel).items() if value == (entity.priority_level))
    entity_xml.lod_level = lod_level
    entity_xml.priority_level = priority_level

    for extension in entity.extensions:
        extension_xml = create_extension_xml(extension)
        entity_xml.extensions.append(extension_xml)

    return entity_xml


def create_room_xml(room: RoomProperties, room_index: int, archetype: ArchetypeProperties) -> ytypxml.Room:
    """Create xml room from a room data-block."""

    room_xml = ytypxml.Room()
    restore_xml(room, room_xml)
    if current_game() == SollumzGame.RDR:
        for probe in room.reflection_probes:
            probe_xml = restore_xml(probe, ytypxml.ReflectionProbe())
            for prop in ('min_extents', 'max_extents', 'center_offset', 'influence_extents', 'probe_priority'):
                setattr(probe_xml, prop, getattr(probe, prop))
            probe_xml.rotation = Quaternion(probe.rotation)
            probe_xml.guid = unsigned(probe.guid)
            room_xml.reflection_probes.append(probe_xml)
    room_xml.name = room.name
    room_xml.bb_min = room.bb_min
    room_xml.bb_max = room.bb_max
    room_xml.blend = room.blend
    room_xml.timecycle_name = room.timecycle
    room_xml.secondary_timecycle_name = room.secondary_timecycle
    room_xml.flags = room.flags.total
    room_xml.floor_id = room.floor_id
    room_xml.exterior_visibility_depth = room.exterior_visibility_depth
    room_xml.portal_count = get_portal_count(
        room, archetype.portals)

    set_room_attached_objects(room_xml, room_index,
                              archetype.non_entity_set_entities)
    preserve_attached_object_order(room, room_xml)

    return room_xml


def create_portal_xml(portal: PortalProperties, portal_index: int, archetype: ArchetypeProperties) -> ytypxml.Portal:
    """Create xml portal from a portal data-block."""

    portal_xml = ytypxml.Portal()
    restore_xml(portal, portal_xml)
    if current_game() == SollumzGame.RDR:
        for prop in ('rdr_7c096c2e', 'rdr_91171666', 'rdr_96816ddf', 'rdr_0854fdee'):
            setattr(portal_xml, prop, getattr(portal, prop))

    set_portal_xml_corners(portal, portal_xml)

    portal_xml.room_from = portal.room_from_index
    portal_xml.room_to = portal.room_to_index
    portal_xml.flags = portal.flags.total
    portal_xml.mirror_priority = portal.mirror_priority
    portal_xml.opacity = portal.opacity
    portal_xml.audio_occlusion = int(
        portal.audio_occlusion)

    set_portal_attached_objects(
        portal_xml, portal_index, archetype.non_entity_set_entities)
    preserve_attached_object_order(portal, portal_xml)

    return portal_xml


def create_tcm_xml(tcm: TimecycleModifierProperties) -> ytypxml.TimeCycleModifier:
    """Create a xml timecycle modifier from a timecycle modifier data-block."""

    tcm_xml = ytypxml.TimeCycleModifier()
    restore_xml(tcm, tcm_xml)
    tcm_xml.name = tcm.name
    tcm_xml.sphere = tcm.sphere
    tcm_xml.percentage = tcm.percentage
    tcm_xml.range = tcm.range
    tcm_xml.start_hour = tcm.start_hour
    tcm_xml.end_hour = tcm.end_hour

    return tcm_xml


def set_extension_xml_props(extension: ExtensionProperties, extension_xml: ymapxml.Extension):
    """Automatically set extension xml properties based on BaseExtensionProperties data-block."""
    extension_xml.name = extension.name
    extension_properties = extension.get_properties()

    extension_xml.offset_position = Vector(extension_properties.offset_position)

    ignored_props = getattr(extension_properties.__class__, "ignored_in_import_export", None) # see LightShaftExtensionProperties

    for prop_name in extension_properties.__class__.__annotations__:
        if ignored_props is not None and prop_name in ignored_props:
            continue

        if extension_xml.get_element(prop_name) is None:
            continue

        prop_value = getattr(extension_properties, prop_name)

        if isinstance(prop_value, Euler):
            prop_value = prop_value.to_quaternion()

        elif prop_name == "effect_hash":
            # `effectHash` needs a hash as decimal value
            prop_value = prop_value.strip()
            if prop_value == "":
                # Default to 0 for empty strings
                prop_value = "0"
            else:
                # Otherwise, get a hash from the string
                prop_value_hash = jenkhash.name_to_hash(prop_value)
                prop_value = str(prop_value_hash)

        elif prop_name == "flashiness":
            # convert enum back to int
            prop_value = Flashiness[prop_value].value

        setattr(extension_xml, prop_name, prop_value)


def create_extension_xml(extension: ExtensionProperties):
    """Create an entity extension from the given extension xml."""

    extension_type = extension.extension_type
    extension_xml_class = ymapxml.ExtensionsList.get_extension_xml_class_from_type(extension_type)

    if extension_xml_class is None:
        # Warning needed here. Unknown extension type
        print(f"Unknown extension type {extension_type}")
        return None

    extension_xml = extension_xml_class()
    restore_xml(extension, extension_xml)

    set_extension_xml_props(extension, extension_xml)
    if current_game() == SollumzGame.RDR and extension.get('_rdr_lights_imported', False):
        extension_xml._rdr_lights_edited = True

    if extension_type == ExtensionType.LIGHT_EFFECT and extension.get_properties().linked_lights_object is not None:
        # Get the light objects and add them to the extension
        lights_obj = extension.get_properties().linked_lights_object

        from ..ydr.lights import create_xml_light_instances
        extension_xml.instances = create_xml_light_instances(lights_obj, extension.get("_rdr_light_group", ""))
        extension_xml._rdr_lights_edited = True

    return extension_xml


def set_archetype_xml_bounds_from_asset(archetype: ArchetypeProperties, archetype_xml: ytypxml.BaseArchetype, apply_transforms: bool = False):
    """Calculate bounds from the archetype asset."""

    if apply_transforms:
        # Unapply only translation
        matrix = Matrix.Translation(
            archetype.asset.matrix_world.translation).inverted()
    else:
        # Unapply all transforms
        matrix = archetype.asset.matrix_world.inverted()

    bbmin, bbmax = get_combined_bound_box(
        archetype.asset, use_world=True, matrix=matrix)
    archetype_xml.bb_min = bbmin
    archetype_xml.bb_max = bbmax
    archetype_xml.bs_center = get_bound_center_from_bounds(bbmin, bbmax)
    archetype_xml.bs_radius = get_sphere_radius(bbmin, bbmax)


def set_archetype_xml_bounds(archetype: ArchetypeProperties, archetype_xml: ytypxml.BaseArchetype, apply_transforms: bool = False):
    """Set archetype xml bounds from archetype data-block bounds."""

    if archetype.asset and archetype.bounds_from_asset:
        set_archetype_xml_bounds_from_asset(
            archetype, archetype_xml, apply_transforms)
        return

    archetype_xml.bb_min = Vector(archetype.bb_min)
    archetype_xml.bb_max = Vector(archetype.bb_max)
    archetype_xml.bs_center = Vector(archetype.bs_center)
    archetype_xml.bs_radius = archetype.bs_radius


def get_xml_asset_type(asset_type: AssetType) -> str:
    """Get xml asset type string from AssetType enum."""

    if asset_type == AssetType.UNITIALIZED:
        return "ASSET_TYPE_UNINITIALIZED"
    elif asset_type == AssetType.FRAGMENT:
        return "ASSET_TYPE_FRAGMENT"
    elif asset_type == AssetType.DRAWABLE:
        return "ASSET_TYPE_DRAWABLE"
    elif asset_type == AssetType.DRAWABLE_DICTIONARY:
        return "ASSET_TYPE_DRAWABLEDICTIONARY"
    elif asset_type == AssetType.ASSETLESS:
        return "ASSET_TYPE_ASSETLESS"
    

def get_xml_map_entity_type(map_entity_type: MapEntityType) -> str:
    """Get xml asset type string from AssetType enum."""

    if map_entity_type == MapEntityType.UNITIALIZED:
        return "MAP_ENTITY_TYPE_UNINITIALIZED"
    elif map_entity_type == MapEntityType.BUILDING:
        return "MAP_ENTITY_TYPE_BUILDING"
    elif map_entity_type == MapEntityType.ANIMATED_BUILDING:
        return "MAP_ENTITY_TYPE_ANIMATED_BUILDING"
    elif map_entity_type == MapEntityType.DUMMY_OBJECT:
        return "MAP_ENTITY_TYPE_DUMMY_OBJECT"
    elif map_entity_type == MapEntityType.COMPOSITE_ENTITY:
        return "MAP_ENTITY_TYPE_COMPOSITE_ENTITY"
    elif map_entity_type == MapEntityType.INTERIOR_INSTANCE:
        return "MAP_ENTITY_TYPE_INTERIOR_INSTANCE"
    elif map_entity_type == MapEntityType.GRASS_BATCH:
        return "MAP_ENTITY_TYPE_GRASS_BATCH"
    elif map_entity_type == MapEntityType.PROP_BATCH:
        return "MAP_ENTITY_TYPE_PROP_BATCH"
    

def create_mlo_archetype_children_xml(archetype: ArchetypeProperties, archetype_xml: ytypxml.MloArchetype):
    """Create all mlo children from an archetype data-block for the provided archetype xml."""
    for entity in archetype.entities:
        if entity.attached_entity_set_id != "-1":
            continue
        archetype_xml.entities.append(create_entity_xml(entity, archetype))

    for room_index, room in enumerate(archetype.rooms):
        archetype_xml.rooms.append(create_room_xml(room, room_index, archetype))

    for portal_index, portal in enumerate(archetype.portals):
        archetype_xml.portals.append(create_portal_xml(portal, portal_index, archetype))

    for tcm in archetype.timecycle_modifiers:
        archetype_xml.timecycle_modifiers.append(create_tcm_xml(tcm))

    for entityset in archetype.entity_sets:
        archetype_xml.entity_sets.append(create_entity_set_xml(entityset, archetype))
    if current_game() == SollumzGame.RDR:
        for volume in archetype.timecycle_volumes:
            volume_xml = restore_xml(volume, ytypxml.TimeCycleVolume())
            for prop in ('name', 'center', 'orientation', 'scale', 'vol_type',
                         'percentage', 'range', 'start_hour', 'end_hour'):
                setattr(volume_xml, prop, getattr(volume, prop))
            archetype_xml.timecycle_volumes.append(volume_xml)
        archetype_xml.uses_activation_volumes = archetype.uses_activation_volumes
        volumes = [(archetype.main_activation_volume, archetype_xml.main_activation_volume)]
        for volume in archetype.extra_activation_volumes:
            volume_xml = ytypxml.ActivationVolume()
            archetype_xml.extra_activation_volumes.append(volume_xml)
            volumes.append((volume, volume_xml))
        for volume, volume_xml in volumes:
            restore_xml(volume, volume_xml)
            volume_xml.bound.sphere = Quaternion((volume.radius, *volume.center))
            volume_xml.flags = unsigned(volume.flags, 32)


def create_archetype_xml(archetype: ArchetypeProperties, apply_transforms: bool = False) -> ytypxml.BaseArchetype:
    """Create archetype xml from an archetype data block"""

    archetype_xml = None

    if archetype.type == ArchetypeType.MLO:
        archetype_xml = ytypxml.MloArchetype()
        archetype_xml.mlo_flags = archetype.mlo_flags.total
        create_mlo_archetype_children_xml(archetype, archetype_xml)
    else:
        if archetype.type == ArchetypeType.TIME:
            archetype_xml = ytypxml.TimeArchetype()
            archetype_xml.time_flags = archetype.time_flags.total
        else:
            archetype_xml = ytypxml.BaseArchetype()
    restore_xml(archetype, archetype_xml)
    if current_game() == SollumzGame.RDR or archetype.type != ArchetypeType.MLO:
        set_archetype_xml_bounds(archetype, archetype_xml, apply_transforms)
   
    if current_game() == SollumzGame.RDR:
        archetype_xml.load_flags = unsigned(archetype.load_flags)
        archetype_xml.avoidanceflags = unsigned(archetype.avoidanceflags, 32)
    archetype_xml.lod_dist = archetype.lod_dist
    archetype_xml.flags = archetype.flags.total
    archetype_xml.special_attribute = SpecialAttribute[archetype.special_attribute].value
    archetype_xml.hd_texture_dist = archetype.hd_texture_dist
    normalize_name = (lambda name: name) if current_game() == SollumzGame.RDR else str.lower
    archetype_xml.name = normalize_name(archetype.name)
    archetype_xml.texture_dictionary = normalize_name(archetype.texture_dictionary)
    archetype_xml.clip_dictionary = archetype.clip_dictionary
    archetype_xml.drawable_dictionary = normalize_name(archetype.drawable_dictionary)
    archetype_xml.physics_dictionary = normalize_name(archetype.physics_dictionary)
    archetype_xml.asset_name = normalize_name(archetype.asset_name)
    archetype_xml.asset_type = get_xml_asset_type(archetype.asset_type)
    if (current_game() == SollumzGame.RDR and archetype.asset_type == AssetType.ASSETLESS
            and archetype.rdr_asset_type_none):
        archetype_xml.asset_type = '-1'
    if current_game() == SollumzGame.RDR:
        archetype_xml.unknown_1 = get_xml_map_entity_type(archetype.unknown_1)
        archetype_xml.guid = unsigned(archetype.guid)
    for extension in archetype.extensions:
        extension_xml = create_extension_xml(extension)
        archetype_xml.extensions.append(extension_xml)

    return archetype_xml


def selected_ytyp_to_xml(apply_transforms: bool = False) -> ytypxml.CMapTypes:
    """Create a ytyp xml from the selected ytyp data-block."""

    selected_ytyp = bpy.context.scene.ytyps[bpy.context.scene.ytyp_index]
    set_import_export_current_game(selected_ytyp.game)
    ytyp_xml = ytypxml.CMapTypes()
    restore_xml(selected_ytyp, ytyp_xml)
    ytyp_xml.name = selected_ytyp.name

    for archetype in selected_ytyp.archetypes:
        archetype_xml = create_archetype_xml(archetype, apply_transforms)
        ytyp_xml.archetypes.append(archetype_xml)

    return ytyp_xml
